from django.shortcuts import render
import pickle
import numpy as np

# Load the pre-trained book models
book = pickle.load(open("book/model/popular.pkl", 'rb'))
same = pickle.load(open("book/model/same.pkl", 'rb'))
pt = pickle.load(open("book/model/pt.pkl", 'rb'))
BOOKS = pickle.load(open("book/model/books.pkl", 'rb'))

def index(request):
    # Data for popular books
    popular_books = []
    for index in range(len(book)):
        popular_books.append({
            "title": book['Book-Title'].iloc[index],
            "author": book['Book-Author'].iloc[index],
            "votes": book['num_rating'].iloc[index],
            "image": book['Image-URL-M'].iloc[index],
            "rating": round(book['avg_rating'].iloc[index], 2),
        })

    return render(request, "index.html", {"data": popular_books})

def recommend(request):
    recommendations = []
    search_results = []
    search_query = ""

    if request.method == 'POST':
        search_query = request.POST.get('query', '').strip()

        # Quick search
        if search_query:
            search_results_df = BOOKS[
                BOOKS["Book-Title"].str.contains(search_query, case=False, na=False)
            ].drop_duplicates(subset="Book-Title").head(1)
            
            # Replace hyphens with underscores in column names
            search_results_df = search_results_df.rename(
                columns={
            "Book-Title": "title",
            "Book-Author": "author",
            "Image-URL-M": "Image_URL_M",
                    }
                
            )

            # Convert results to a dictionary
            search_results = search_results_df.to_dict(orient='records')

            try:
                index = np.where(pt.index == search_query)[0][0]
                similar = sorted(
                    list(enumerate(same[index])),
                    key=lambda x: x[1],
                    reverse=True
                )[1:5]

                seen_titles = set()
                for i in similar:
                    temp = BOOKS[BOOKS["Book-Title"] == pt.index[i[0]]]
                    for _, row in temp.iterrows():
                        if row["Book-Title"] not in seen_titles:
                            seen_titles.add(row["Book-Title"])
                            recommendations.append({
                                "title": row["Book-Title"],
                                "author": row["Book-Author"],
                                "image": row["Image-URL-M"]
                            })
            except KeyError:
                print(f"Book '{search_query}' not found in the dataset.")
            except IndexError:
                print(f"No similar books found for '{search_query}'.")

    return render(request, 'recommend.html', {
        "search_query": search_query,
        "search_results": search_results,
        "recommendations": recommendations,
    })

